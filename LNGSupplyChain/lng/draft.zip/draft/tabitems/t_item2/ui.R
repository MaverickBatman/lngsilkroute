fluidRow(
  titlePanel("t2_abcd"),
  box(
    title = "t2_Distribution",
    status = "primary",
    plotOutput("t2_plot1", height = 240),
    height = 300
  ),
  tabBox(
    height = 300,
    tabPanel("t2_View 1",
             plotOutput("t2_scatter1", height = 230)
    ),
    tabPanel("View 2",
             plotOutput("t2_scatter2", height = 230)
    )
  )
)
