fluidRow(
  titlePanel("t3_abcd"),
  box(
    title = "t3_abcdDistribution",
    status = "primary",
    plotOutput("t3_plot1", height = 240),
    height = 300
  ),
  tabBox(
    height = 300,
    tabPanel("View 1",
             plotOutput("t3_scatter1", height = 230)
    ),
    tabPanel("View 2",
             plotOutput("t3_scatter2", height = 230)
    )
  )
)
