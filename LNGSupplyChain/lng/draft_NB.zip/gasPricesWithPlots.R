# Load the ggplot2 package which provides
# the 'mpg' dataset.
library(ggplot2)
price.data <- dbGetQuery(mydb, 'SELECT * FROM user_market_prices')
price.data
ui <- fluidPage(
  titlePanel("Natural Gas Prices"),
  
  # Create a new Row in the UI for selectInputs
  fluidRow(
    column(4,
           selectInput("Market",
                       "Price:",
                       c("All",
                         unique(as.character(price.data$Market))))
    
    )
  ),
  # Create a new row for the table.
  DT::dataTableOutput("table"),
  
  #plot the graph
  fluidRow(
    column(width = 4,
           plotOutput("plot1", height = 300,
                      # Equivalent to: click = clickOpts(id = "plot_click")
                      click = "plot1_click",
                      brush = brushOpts(
                        id = "plot1_brush"
                      )
           )
    )
  )
  
)



server <- function(input, output) {
  
  # Filter data based on selections
  output$table <- DT::renderDataTable(DT::datatable({
    data <- price.data
    
   if (input$Market != "All") {
   data <- data[data$Market == input$Market,]
   }
   data
  }))
  
  # Filter data based on selections
  
  
  
  output$plot1 <- renderPlot({
    ggplot(data, aes(x= data$Contract_End, y=data$Mid, colour=factor(smooth))) +
      geom_line()
  })
  
}


shinyApp(ui, server)
