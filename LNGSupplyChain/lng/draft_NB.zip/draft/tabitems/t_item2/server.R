t2_routeFile <- readLines("out.csv")
t2_routeFileLine <- t2_routeFile[2]
t2_inputstr  <- str_extract(string = t2_routeFileLine, ".*[}]")
write_file(t2_inputstr, "out.geojson")
t2_route <- geojsonio::geojson_read("out.geojson", what = "sp")



observeEvent(input$t2_route_calc, {
  t2_src <- input$t2_port_select_source_port
  t2_dest <- input$t2_port_select_dest_port
  
  t2_src_lat = t2_ports[which(t2_ports[,3] == t2_src & t2_ports[,4] == input$t2_port_select_source_country, arr.ind = TRUE),]$lat
  t2_src_lon = t2_ports[which(t2_ports[,3] == t2_src & t2_ports[,4] == input$t2_port_select_source_country, arr.ind = TRUE),]$lon
  t2_dest_lat = t2_ports[which(t2_ports[,3] == t2_dest & t2_ports[,4] == input$t2_port_select_dest_country, arr.ind = TRUE),]$lat
  t2_dest_lon = t2_ports[which(t2_ports[,3] == t2_dest & t2_ports[,4] == input$t2_port_select_dest_country, arr.ind = TRUE),]$lon
  
  t2_routeFileInput <- ""
  t2_routeFileInput <- paste("route name,olon,olat,dlon,dlat\n",
                             t2_src, "-", t2_dest, ",",
                             t2_src_lon, ",", t2_src_lat, ",",
                             t2_dest_lon, ",", t2_dest_lat, sep = "")
  write.table(x = t2_routeFileInput, file = "test_input.csv", row.names = FALSE, col.names = FALSE, quote = FALSE)
  system("java -jar searoute.jar -i \"test_input.csv\"")
  t2_routeFile <- readLines("out.csv")
  t2_routeFileLine <- t2_routeFile[2]
  t2_inputstr  <- str_extract(string = t2_routeFileLine, ".*[}]")
  write_file(t2_inputstr, "out.geojson")
  t2_route <- geojsonio::geojson_read("out.geojson", what = "sp")
  
  leafletProxy("t2_mymap") %>%
    clearShapes() %>%
    clearMarkers() %>%
    addMarkers(lng = t2_src_lon,
               lat = t2_src_lat,
               #popup = t2_src,
               label = t2_src,
               #popupOptions = popupOptions(keepInView = TRUE), 
               labelOptions = labelOptions(noHide = TRUE),
               options = markerOptions(riseOnHover = TRUE),
               group = "Route"
    ) %>%
    addMarkers(lng = t2_dest_lon,
               lat = t2_dest_lat,
               #popup = t2_dest,
               label = t2_dest,
               #popupOptions = popupOptions(keepInView = TRUE), 
               labelOptions = labelOptions(noHide = TRUE),
               options = markerOptions(riseOnHover = TRUE),
               group = "Route"
    ) %>%
    addPolylines(data = t2_route,
                 group = "Route",
                 popup = paste("From: <b>", t2_src, "</b></br>", "To: <b>", t2_dest, "</b>")) %>%
    flyToBounds(lng1 = t2_src_lon, lat1 = t2_src_lat, lng2=t2_dest_lon, lat2=t2_dest_lat)
})

observeEvent(input$t2_port_select_source_country, {
  t2_ports_src <- t2_ports[t2_ports$Wpi_country_code == input$t2_port_select_source_country,]$Main_port_name
  updateSelectInput(session = session, inputId = "t2_port_select_source_port",
                    choices = t2_ports_src)
})

observeEvent(input$t2_port_select_dest_country, {
  t2_ports_dest <- t2_ports[t2_ports$Wpi_country_code == input$t2_port_select_dest_country,]$Main_port_name
  updateSelectInput(session = session, inputId = "t2_port_select_dest_port",
                    choices = t2_ports_dest)
})

output$t2_mymap <- renderLeaflet({
  leaflet() %>%
    #addTiles() %>%
    addTiles(options = tileOptions(noWrap = TRUE, minZoom = 2)) %>%
    setView(lng = 0, lat = 0, zoom = 2) %>%
    # addProviderTiles(provider = providers$Stamen.TonerLite,
    #                  options = providerTileOptions(noWrap = TRUE),
    #                  layerId = "Stamen.TonerLite") %>%
    # addProviderTiles(provider = providers$OpenStreetMap.Mapnik,
    #                  options = providerTileOptions(noWrap = TRUE),
    #                  layerId = "OpenStreetMap.Mapnik") %>%
    # addProviderTiles(provider = providers$OpenInfraMap.Water,
    #                  options = providerTileOptions(noWrap = TRUE),
    #                  layerId = "OpenInfraMap.Water") %>%
    # addProviderTiles(provider = providers$Stamen.TonerLines,
    #                  options = providerTileOptions(noWrap = TRUE),
  #                  layerId = "Stamen.TonerLines") %>%
  addCircleMarkers(
    data = t2_ports,
    lat =  ~ lat,
    lng = ~ lon,
    radius = 3,
    label =  ~ Main_port_name,
    clusterOptions = markerClusterOptions(),
    group = "Ports"
  ) %>%
    addLayersControl(
      baseGroups = c("Stamen.TonerLite", "OpenStreetMap.Mapnik", "OpenInfraMap.Water", "Esri.OceanBasemap"),
      overlayGroups = c("Ports", "Route"),
      options = layersControlOptions(collapsed = FALSE)
    )
  
  
})
