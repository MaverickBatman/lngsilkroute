fluidRow(
  titlePanel("t2_abcd"),
  leaflet::leafletOutput("t2_mymap"),
  
  shinyWidgets::dropdownButton(
    
    
    shiny::h5("List of Inputs"),
    shiny::selectizeInput(
      inputId = "t2_port_select_source_country",
      label = "Source Country:",
      choices = t2_countries,
      selected = "US"
    ),
    shiny::selectizeInput(
      inputId = "t2_port_select_source_port",
      label = "Source Port:",
      choices = t2_ports_src
    ),
    shiny::selectizeInput(
      inputId = "t2_port_select_dest_country",
      label = "Destination Country:",
      choices = t2_countries,
      selected = "IN"
    ),
    shiny::selectizeInput(
      inputId = "t2_port_select_dest_port",
      label = "Destination Post:",
      choices = t2_ports_dest
    ),
    shiny::actionButton(
      inputId = "t2_route_calc",
      label = "Find Route"),
    circle = TRUE,
    icon = icon("gear"),
    width = "300px",
    status = "danger",
    tooltip = shinyWidgets::tooltipOptions(title = "Click to see inputs"),
    up = TRUE
  )
)
