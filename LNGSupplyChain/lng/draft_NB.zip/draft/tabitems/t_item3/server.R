
file1 <-read.csv('db\\Inventory.csv', header = TRUE)
t3_temp <- read.csv('db\\Coordinates.csv', header = TRUE)
#col_plot = c("Beginning_Inventory","Ending_Inventory")
#dlong <- melt(file1[,c("Start_Date", col_plot)], id.vars="Start_Date")  
# file1 <- melt(file1, id.vars="Start_Date")

theme_set(theme_bw())

df <- file1[file1$variable %in% c("Loaded", "Delivered"), ]
df$DATE <- as.Date(df$DATE)
output$dateRange <- renderUI({
  browser()
  date_start <- as.character(input$dateRange[1])
  date_end <- as.character(input$dateRange[2])
})


# yearPlot <- function(yr, title = paste("U.S LNG Export tracker", as.character(yr))) {
#   
#   top8 <- temp %>%
#     filter(temp$Display == "LNG") %>% 
#     
#     arrange(desc(temp$Volume))            
#   top8 <- top8[1:8,]
#   
#   temp <- filter(temp, temp$Location %in% top8$Location)  #filtering by the Location
#   
#   
#   
#   temp$Capacity <- ordered(temp$Capacity, levels = c("Deliveries", "Op_cap"))
#   #setting the level order for the Demographic
#   # attribute so the smaller values on the bar plot
#   # aren't hidden
#   
#   
#   plot <- ggplot(temp, aes(x =  temp$Location, y = Volume, fill = temp$Capacity)) +
#     geom_bar(stat = "identity", position = "identity", alpha = .65) +
#     coord_flip() +
#     scale_fill_manual(values = c("skyblue4", "skyblue1")) +
#     ylab("Volume") +
#     theme_minimal() +
#     theme(axis.text.y = element_text(size = 7, angle = 30),
#           axis.title.y = element_blank(),
#           axis.text.x = element_blank())
#   ggplotly(plot)    #making the plot interactive
# }    
# yearPlot(2019)

output$chart1 <-renderPlot({

  # 
  # ggplot(data=file, aes(x=Ending_Inventory, y=Beginning_Inentory)) +
  #   geom_bar(stat="identity", width=100)+v
  #     geom_text(aes(label=Ending_Inventory), vjust=-0.3, size=3.0)+
  #     theme_minimal()n
  
  
  #ggplot(data=subset(file1, Start_Date > as.Date("1/1/2019")), 
  # aes(x=Date, y=Inventory))+geom_line()
  
  
  
  
  
  # df <- df[lubridate::day(df$Start_Date) %in% c(2019:2019), ]
  # # labels and breaks for X axis text
  # brks <- df$Start_Date[seq(1, length(cdf$Start_Date)),1]
  # lbls <- lubridate::day(brks)
  
  
  # plot
  date_start <- as.character(input$daterange[1])
  date_end <- as.character(input$daterange[2])
  if(is.null(input$daterange[1])) return()
  
  file1$DATE <- as.Date(file1$DATE,format="%Y-%m-%d")
  # # data <- data %>% filter(RequestedDtTm >= date_start & RequestedDtTm <= date_end)
  #file1 <- file1[as.Date(file1$DATE) >= date_start & as.Date(file1$Date) <= date_end, ]
  dfhist<- subset(file1, file1$DATE >= as.Date(input$daterange[1]) & file1$DATE <= 
                    as.Date(input$daterange[2]) )
  
  ggplot(dfhist, aes(x= DATE,y =VOLUME_MMBTU )) + 
    geom_line(aes(y=VOLUME_MMBTU, col=VARIABLE)) + 
    labs(title="Time Series Inventory", 
         subtitle="Drawn from Long Data format", 
         
         y="VOLUME_MMBTU", 
         color=NULL) +  # title and caption
    scale_x_date(date_labels = "%b-%d-%Y") + 
    scale_color_manual(labels = c("Delivered", "Loaded"), 
                       values = c("Loaded"="#00ba38", "Delivered"="#f8766d")) +  # line color
    theme(axis.text.x = element_text(angle = 90, vjust=0.5, size = 8),  # rotate x axis text
          panel.grid.minor = element_blank())  # turn off minor grid
  
  
  # 
  # df_sorted <- arrange(file, Ending_Inventory, Beginning_Inventory) 
  # head(df_sorted)
  # df_cumsum <- ddply(df_sorted, "Ending_Inventory",
  #                    transform, 
  #                    label_ypos=cumsum(Beginning_Inventory) - Ending_Inventory)
  # # Create the barplot
  # ggplot(data=df_cumsum, aes(x=Start_Date, y=Beginning_Inventory ,fill=Commodity)) +
  #   geom_line()+
  #   geom_point()
  #  
  #   scale_fill_brewer(palette="Paired")+
  #   theme_minimal()
  # 
  
  
})




output$chart2 <- renderPlot({
 
  #agg = aggregate(file1, by = list(file1$DATE),                     FUN = sum())
  file1$DATE <- as.Date(file1$DATE)
  dfhist<- subset(file1, file1$DATE >= as.Date(input$daterange[1]) & file1$DATE <= 
                    as.Date(input$daterange[2]) )
  
  ggplot(dfhist, aes(x = DATE, y =VOLUME_MMBTU)) +
    geom_bar(stat = "identity", aes(fill = VOLUME_MMBTU), legend = FALSE) + 
    stat_summary(aes(label = ..y..), fun.y = 'sum', geom = 'text', col = 'white', vjust = 1.5) +
    #scale_y_continuous("Volume", labels = percent_format()) +
    scale_y_continuous("Volume, MMBTU")
  
  #opts(axis.title.x = theme_blank())
  
  
}) 


output$barplot <- renderPlotly({
  browser()
  
  yearPlot(input$Year)
  
  
  

  
  # 
  # g <- list(
  #   scope = "usa",
  #   projection = list(type = "albers usa"),
  #   showland = TRUE,
  #   landcolor = toRGB("gray95"),
  #   subunitcolor = toRGB("gray85"),
  #   countrycolor = toRGB("gray85"),
  #   countrywidth = 0.5,
  #   subunitwidth = 0.5
  # )
  # 
  # mapPlot<-
  # 
  # function(yr) {
  #  
  #   p <- plot_geo(tmp, Latitude = ~Latitude, Longitude = ~Longitude, 
  #                 color = ~Capacity, 
  #                 colors = c("skyblue1", "skyblue4"), 
  #                 size = ~Volume,
  #                 sizes = c(10, 300),
  #                 alpha = 0.65,
  #                 text = ~paste('Capacity: ', Capacity, 
  #                               '</br> Location: ', Location,
  #                               '</br> Volume: ', Volume)) %>%
  #     add_markers() %>%
  #     layout(geo = g)
  #   print(p)
}
)


output$t3_mymap <- renderLeaflet({
  #browser()
  leaflet() %>%
    #addTiles() %>%
    addTiles(options = tileOptions(noWrap = TRUE, minZoom = 2)) %>%
    setView(lng = 0, lat = 0, zoom = 2) %>% 
    addMarkers(data = t3_temp,
               lng = ~Longitude  ,
               lat = ~Latitude,
              popup = paste("Capacity:", t3_temp$Capacity, "</br>", "Volume:", t3_temp$Volume)
               #label = t2_dest,
               #popupOptions = popupOptions(keepInView = TRUE),
               #labelOptions = labelOptions(noHide = TRUE),
               #options = markerOptions(riseOnHover = TRUE),
               #group = "Route"
    )
})


