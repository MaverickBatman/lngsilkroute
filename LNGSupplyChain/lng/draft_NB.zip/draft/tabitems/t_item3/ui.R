
location_name <- read.csv('db\\Location_name.csv', header = TRUE)
location_name <- droplevels(filter(location_name))

fluidRow(
  splitLayout(
    dateRangeInput("daterange", "Select Date range:",
                   start = "2019-01-01",
                   end = "2019-12-31", min = "2008-01-01", max="2019-12-31"),
    selectInput('location_name', 'Location', as.character(levels(location_name$location_name)), selected="United States")),
  #A line break to make the interface clearer 
  br(),
  
  box(title = "Daily LNG Beginning and Ending Inventory", status = "primary", solidHeader = TRUE,
      collapsible = TRUE,collapsed = TRUE, plotOutput("chart1", height = 250, width = 300)),
  
  
  box(title = "Daily Net LNG Inventory Change", status = "primary", solidHeader = TRUE,
      collapsible = TRUE, collapsed = TRUE, plotOutput("chart2", height = 250, width = 300)),
  
  
  
 # box(title = "Map", status = "primary", solidHeader = TRUE,
     # collapsible = TRUE, collapsed = TRUE, plotlyOutput("barplot", height = 250, width = 300))
  box(title = "Map", status = "primary", solidHeader = TRUE,
      collapsible = TRUE, collapsed = TRUE, leaflet::leafletOutput("t3_mymap"))
)







